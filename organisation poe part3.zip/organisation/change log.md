#Part 2 improvement

from the feedback i got from my lecturer 
<Link rel="stylesheet" type="text/css" href="style.css">

2. for the final poe i was required to create a website using html style to website using external css then add html formate so that i can be able to do form validation using java script
3. i also plan to add a gallery to the website with all the images that will show users a glimpse in what sevices and resources we plan to provide 
4. i will improve my google maps making it interactive for  the user
5. i have added smoother transitions for the content on the website to apear more seamless for useers
6. ive improved both my forms on the enquiry and contact pages making them more discriptive for users not to get confused when filling them out such as what information is required from them and which are optional 
7. i am going to add SEO in all my web pages using the meta text





references 
1. https://www.w3schools.com/htmlcss/htmlcss_forms_validation.asp
2. https://www.w3schools.com/howto/howto_js_lightbox.asp
3. https://www.w3schools.com/tags/tag_meta.asp